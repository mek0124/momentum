# Momentum Codebase Technical Analysis

## 1. Project Identity

**Name:** Momentum
**Version:** 0.1.0
**Description:** A local-first task management application with CLI, TUI, and GUI interfaces that share a common core.
**License:** MIT
**Author:** mek0124 (mek0124@proton.me)
**Repository:** https://github.com/mek0124/momentum
**Philosophy:** Local-first, minimalist, hackable, no lock-in, simple SQLite storage

## 2. Tech Stack

### Core Technologies
- **Language:** Python 3.12+
- **Database:** SQLite (via SQLAlchemy 2.0+ ORM)
- **Build System:** setuptools + wheel (pyproject.toml)

### Interface-Specific Libraries
- **CLI:** Click 8.3+ (command-line argument parsing)
- **TUI:** Rich 14.3+ (terminal formatting, tables, panels)
- **GUI:** PySide6 6.10+ (Qt bindings) + pyside6-fluent-widgets 1.11+ (Fluent UI design system)

### Supporting Libraries
- **dotenv:** python-dotenv 1.2.2 (environment variable loading)
- **Path handling:** pathlib (standard library)

### Development Tools
- **Code Formatting:** Black, isort
- **Type Checking:** mypy
- **Linting:** flake8
- **Testing:** pytest, pytest-asyncio
- **Building:** build

## 3. Architecture

### Overall Pattern: Modular Monorepo

Momentum follows a **modular monorepo** architecture where multiple installable packages share a common core:

```
momentum/
├── cli/       (momentum-cli)     → Command-line interface
├── tui/       (momentum-tui)     → Terminal UI
├── gui/       (momentum-gui)     → Desktop GUI
└── core/      (momentum-core)    → Shared business logic
```

### Design Principles
- **Separation of Concerns:** Each interface is completely separate but imports and uses the shared `core.logic.Logic` class
- **Dependency Flow:** CLI/TUI/GUI → Core → Database (unidirectional)
- **Local-First:** All data stored locally in `~/.momentum/main.db`
- **No External Services:** No cloud dependency, no telemetry, no accounts

### Key Architectural Decisions
1. **Single Logic Class:** The `Logic` class in `core/logic.py` is the sole entry point for all business operations. It's instantiated by each interface with the app directory path.
2. **Direct Database Access:** Interfaces don't talk to the database directly; all data operations go through the Logic layer.
3. **Shared Configuration:** The `~/.momentum/` directory and `config.json` are shared across all interfaces.
4. **Package Distribution:** Each interface is its own installable package with `momentum-core` as a dependency. Root `pyproject.toml` can install all three at once.

## 4. Directory Structure

```
momentum/
├── .git/                    # Git repository
├── .gitignore              # Ignores: __pycache__, core/storage/, build/, dist/, *.egg-info, *.spec
├── .python-version         # Specifies Python 3.12
├── LICENSE.txt             # MIT License
├── README.md               # Project documentation (204 lines)
├── CONTRIBUTING.md         # Contribution guidelines (76 lines)
├── CHANGELOG.md            # Change log (78 lines)
├── pyproject.toml          # Root package configuration (install all)
│
├── cli/                    # CLI interface package
│   ├── __init__.py        # (MISSING - not packaged yet)
│   ├── main.py            # Click group definition, Logic instantiation
│   ├── commands.py        # CLI commands: hello, add, edit, delete, list
│   └── pyproject.toml     # Package: momentum-cli
│
├── tui/                    # TUI interface package
│   ├── __init__.py        # (MISSING - not packaged yet)
│   ├── main.py            # MomentumConsole class, Rich UI, main loop
│   └── pyproject.toml     # Package: momentum-tui
│
├── gui/                    # GUI interface package
│   ├── __init__.py        # Exports Momentum class
│   ├── main.py            # Momentum window (MSFluentWindow), app startup
│   ├── pages/
│   │   ├── __init__.py
│   │   └── dashboard.py   # Main dashboard with task cards and form
│   └── pyproject.toml     # Package: momentum-gui
│
└── core/                   # Core logic package
    ├── __init__.py        # Exports Logic class
    ├── logic.py           # Business logic (CRUD, config, DB init)
    ├── pyproject.toml     # Package: momentum-core
    │
    ├── assets/
    │   └── icon.png       # Application icon
    │
    ├── database/
    │   ├── __init__.py    # Exports get_base, get_engine, get_db
    │   └── db.py          # SQLAlchemy engine, SessionLocal, Base setup
    │
    ├── models/
    │   ├── __init__.py    # Exports Task
    │   └── task.py        # SQLAlchemy Task model (id, title, content)
    │
    └── utils/
        ├── __init__.py    # Exports COLOR_THEME
        └── color_theme.py  # Color constants for UI theming
```

## 5. Key Components and Relationships

### Core Module (`momentum-core`)

#### Logic Class (`core/logic.py`)
- **Purpose:** Central business logic orchestrator
- **Responsibilities:**
  - Application directory setup (`~/.momentum/`)
  - User agreement management (first-run consent)
  - Database initialization (`metadata.create_all()`)
  - CRUD operations on tasks
  - Error handling and user feedback

- **Key Methods:**
  - `__init__(app_dir: Path)`: Constructor, calls `setup_environment()`
  - `setup_environment()`: Ensures app directory exists, checks config, gets user agreement if needed, initializes DB
  - `get_user_agreement()`: Interactive console prompt for consent
  - `save_task(title, content) -> (bool, str)`: Creates new task, validates unique title
  - `update_task(task_id, new_title, new_content) -> (bool, str)`: Updates existing task
  - `delete_task(task_id) -> (bool, str)`: Removes task
  - `get_all_tasks() -> List[Task]`: Retrieves all tasks
  - `get_task_by_id(task_id) -> Task | None`: Retrieves single task

- **Dependencies:** Imports from `core.database` and `core.models`

#### Database Module (`core/database/db.py`)
- **Purpose:** SQLAlchemy configuration and session management
- **Key Objects:**
  - `Base`: declarative base for models
  - `engine`: SQLAlchemy engine (SQLite by default at `~/.momentum/main.db`)
  - `SessionLocal`: session factory (autocommit=False, autoflush=False)
  - `get_db()`: Generator that yields a session and ensures cleanup

- **Configuration:**
  - Checks `SQLALCHEMY_DB_URL` or `SQLALCHEMY_DATABASE_URL` env vars
  - Falls back to local SQLite in home directory
  - `connect_args={"check_same_thread": False}` for SQLite

#### Task Model (`core/models/task.py`)
- **SQLAlchemy Model:** `Task`
- **Table:** `tasks`
- **Columns:**
  - `id`: Integer, primary key, indexed
  - `title`: String, unique, indexed
  - `content`: String (no length limit, could be TEXT in SQLite)
- **Missing Fields:** No timestamps, no priority, no status, no due dates (according to current scope)

#### Color Theme (`core/utils/color_theme.py`)
- **Purpose:** Centralized color definitions for UI consistency
- **Target Users:** TUI (Rich) and GUI (PySide6 stylesheets)
- **Color Palette:** Dark theme with electric green primary (#00FF9D), cyan-green accent (#00FFC8)
- **Values Provided:** Background, surfaces, text colors, status colors (success, warning, error), borders, shadows, spacing constants

### CLI Module (`cli/`)

**Entry Point:** `momentum` (defined in root `pyproject.toml`)

- **main.py:**
  - Defines `@click.group` decorated function `cli(ctx)`
  - Instantiates `Logic` with `~/.momentum/`
  - Registers subcommands from `commands.py`

- **commands.py:**
  - `hello_command`: Greets user (default "User")
  - `add_command`: Creates task via `logic.save_task()`
  - `edit_command`: Updates task via `logic.update_task()`
  - `delete_command`: Deletes task via `logic.delete_task()`
  - `list_command`: Prints all tasks in simple format with separators

**Design Pattern:** Click command groups with context passing (`@click.pass_context`)

### TUI Module (`tui/`)

**Entry Point:** `momentum-tui`

- **main.py:**
  - `MomentumConsole` class encapsulates entire TUI
  - Uses Rich: Console, Table, Panel, Prompt, Confirm, Text, box
  - Main loop in `run()` method with menu choices 1-5
  - Features:
    - View all tasks in a formatted table
    - Add task with multi-line content (terminates with '.')
    - Edit task (pre-fills form, allows keeping current values)
    - Delete task with confirmation
    - Exit
  - Color theme imported from `core.utils.color_theme`
  - Logic instance passed to constructor

**Design Pattern:** Console-based menu loop with procedure-per-feature methods

### GUI Module (`gui/`)

**Entry Point:** `momentum-gui`

- **main.py:**
  - `Momentum` class inheriting from `MSFluentWindow` (qfluentwidgets)
  - Sets dark theme and theme color from `COLOR_THEME['primary']`
  - Applies background color from theme
  - Creates `Dashboard` page and adds to navigation
  - Loads icon from `core/assets/icon.png`
  - Window size: min 800x600

- **pages/dashboard.py:**
  - `Dashboard` class inheriting from `QWidget`
  - **Layout:** Split panel (HBoxLayout)
    - Left: Task cards scroll area (3/4 width)
    - Right: Input form (1/4 width)
  - **Task Cards:**
    - Display in responsive grid (4 columns)
    - Fixed size: 250x300
    - Shows title, content, Edit/Delete buttons
    - Styled with theme colors
  - **Input Form:**
    - Title field: QLineEdit
    - Content field: QTextEdit (multi-line)
    - Buttons: Clear (resets form), Create/Update (contextual)
  - **Functionality:**
    - `load_tasks()`: Refreshes task display and form
    - `populate_form()`: Fills form with task data for editing
    - `save_task()`: Validates and creates new task
    - `update_task()`: Validates and updates existing task
    - `delete_task()`: Removes task
    - `handle_error_success()`: Shows status bar message with color coding
  - **State:** Tracks `editing_id` to differentiate create vs update

**Design Pattern:** Widget-based MVC-lite (Dashboard is View + Controller; Logic is Model)

## 6. Data Layer

### Database
- **Type:** SQLite (file-based)
- **Location:** `~/.momentum/main.db` (default)
- **Alternative:** Override with `SQLALCHEMY_DB_URL` or `SQLALCHEMY_DATABASE_URL` environment variables

### ORM
- **Library:** SQLAlchemy 2.0+ (modern API)
- **Setup:**
  - `create_engine()` with `check_same_thread=False` for SQLite
  - `declarative_base()` for model inheritance
  - `sessionmaker` with autocommit=False, autoflush=False
- **Session Management:** Generator-based context manager (`get_db()`) that yields a session and closes it in `finally` block

### Schema
```sql
CREATE TABLE tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR NOT NULL UNIQUE,
    content VARCHAR
);
```
- **Only one table:** `tasks`
- **Indexes:** id (primary), title (unique, indexed)
- **No migrations:** Uses `metadata.create_all()` at startup (auto-creates if not exists)

### Data Access Pattern
- **Not Repository Pattern:** Logic class directly queries using session
- **Session Scope:** Each CRUD method in `Logic` gets a fresh session via `next(get_db())`
- **Transaction Management:** Manual commit/rollback in try/except blocks

## 7. API Design

### Not a Web API
This is a desktop application suite, not a web service. However, the `Logic` class provides a clean internal API:

```
Logic(app_dir: Path)
├── save_task(title: str, content: str) -> Tuple[bool, str]
├── update_task(task_id: int, new_title: str, new_content: str) -> Tuple[bool, str]
├── delete_task(task_id: int) -> Tuple[bool, str]
├── get_all_tasks() -> List[Task] | None
└── get_task_by_id(task_id) -> Task | None
```

- **Return Signature:** Always returns `(success: bool, message: str)` for write operations
- **Error Handling:** Catches generic `Exception`, prints to console, rolls back transaction, returns failure message
- **Validation:**
  - `save_task()`: Requires both title and content; checks for duplicate title
  - `update_task()`: Requires at least one of title/content; validates task existence
  - `delete_task()`: Validates task existence

## 8. Frontend/UI

### Three Separate UIs with Different Stacks

#### CLI
- **Framework:** Click
- **Pattern:** Command group with subcommands
- **Commands:**
  - `momentum hello [--name NAME]`
  - `momentum add --title TITLE --content CONTENT`
  - `momentum edit --id ID [--title TITLE] [--content CONTENT]`
  - `momentum delete --id ID`
  - `momentum list`
- **Output:** Plain text with separator lines
- **No color:** Basic terminal output only

#### TUI
- **Framework:** Rich (console rendering)
- **Components:**
  - Header panel with title and version
  - Menu panel with numbered options
  - Tables with borders for task list
  - Input prompts for data entry
  - Multi-line content input ('.' to finish)
- **Interactions:** Numbered choices, text prompts, yes/no confirmations
- **Theme:** Uses `COLOR_THEME` dict for consistent colors across TUI and GUI

#### GUI
- **Framework:** PySide6 (Qt6) + qfluentwidgets (Microsoft Fluent Design)
- **Window:** `MSFluentWindow` with navigation sidebar
- **Main Page:** Dashboard with:
  - **Task Grid:** Cards arranged in 4-column responsive layout
  - **Task Card:** Title, content preview, Edit/Delete buttons
  - **Input Form:** Title (single line), Content (multi-line), Clear/Submit buttons
  - **Status Bar:** Shows success/error messages with background color
- **Theming:** Dark theme, electric green accent color, custom stylesheets referencing `COLOR_THEME` values
- **Event Handling:** Signal/slot connections for buttons (Edit populates form, Delete confirms and removes)

**Note:** GUI currently has only one page (Dashboard). Navigation infrastructure exists via `MSFluentWindow.addSubInterface()` but no additional pages implemented.

## 9. Configuration

### Configuration Storage
- **Directory:** `~/.momentum/` (created on first run)
- **File:** `config.json`
  ```json
  {
    "agree": 1
  }
  ```
- **Purpose:** Stores user's consent to read/write permissions

### Environment Variables
- `SQLALCHEMY_DB_URL` or `SQLALCHEMY_DATABASE_URL`: Override default SQLite database location
- Example: `export SQLALCHEMY_DB_URL=postgresql://user:pass@localhost/dbname`

### Configuration Management
- **No advanced config:** Only user agreement flag currently stored
- **Logic.setup_environment():**
  1. Creates app directory if missing
  2. Reads `config.json` if exists
  3. If `agree != 1`, calls `get_user_agreement()`
  4. On agreement, writes `{"agree": 1}` to config
  5. Initializes database (`init_db()`)

### Future Config Possibilities
- Theme customization (colors)
- Database location
- UI preferences (font size, layout)
- Task defaults (priorities, categories)

## 10. Testing

### Status: NOT IMPLEMENTED

- **Dev Dependencies Declared:** pytest, pytest-asyncio in root `pyproject.toml`
- **Reality:** No test files found in repository
- **Coverage:** 0% (no tests executed)
- **Test Framework:** pytest (if added)
- **Missing:**
  - Unit tests for `Logic` class
  - Integration tests for database operations
  - UI tests for TUI/GUI (could use pytest-qt, pytest-rich)
  - Mocking strategy for database sessions

### Suggested Test Structure
```
tests/
├── unit/
│   ├── test_logic.py
│   ├── test_database.py
│   └── test_models.py
├── integration/
│   └── test_cli_commands.py
└── conftest.py
```

## 11. Build/Deploy

### Build System
- **Tool:** setuptools (via pyproject.toml)
- **Build Backend:** `setuptools.build_meta`
- **Package Format:** Wheel (`.whl`)

### Packages (4 total)
1. **momentum-core** (`core/pyproject.toml`)
   - Version: 1.0.0
   - Dependencies: sqlalchemy>=2.0.0, python-dotenv>=1.2.2
   - Includes: assets/* (icon.png)

2. **momentum-cli** (`cli/pyproject.toml`)
   - Version: 1.0.0
   - Dependencies: momentum-core>=0.1.0, click>=8.3.1
   - Entry point: `momentum = cli.main:cli`

3. **momentum-tui** (`tui/pyproject.toml`)
   - Version: 1.0.0
   - Dependencies: momentum-core>=0.1.0, rich>=14.3.3
   - Entry point: `momentum-tui = tui.main:main`

4. **momentum-gui** (`gui/pyproject.toml`)
   - Version: 0.1.0
   - Dependencies: momentum-core>=0.1.0, pyside6>=6.10.2, pyside6-fluent-widgets>=1.11.1
   - Entry point: `momentum-gui = gui.main:main`

### Installation

**Development:**
```bash
git clone https://github.com/mek0124/momentum.git
cd momentum
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

**Production (all interfaces):**
```bash
pip install -e .
# Installs all three entry points: momentum, momentum-tui, momentum-gui
```

**Individual Interfaces:**
```bash
pip install -e cli/     # Only CLI
pip install -e tui/     # Only TUI
pip install -e gui/     # Only GUI
```

### Deployment
- **No CI/CD:** No GitHub Actions, Travis, GitLab CI found
- **No Docker:** No containerization
- **Distribution:** PyPI publishing possible but not configured
- **Platform Support:** Cross-platform (Python 3.12+, SQLite, PySide6 supports Windows/macOS/Linux)

### Updater Mention
- CHANGELOG references an "updater application" that was added then removed (commit 2dd5221)
- Current version does not include auto-update capability

## 12. Code Quality

### Style Guidelines
- **Standard:** PEP8 + Black
- **Enforced:** Through CONTRIBUTING.md instructions (not automated pre-commit hooks)
- **Commands to run before committing:**
  ```bash
  black .
  flake8 .
  pytest
  ```

### Current State
- **Formatting:** Code appears to be manually formatted; no evidence of automated enforcement
- **Linting:** flake8 configured but not in pyproject.toml (would need .flake8 config)
- **Type Hints:** Partial usage in `logic.py` (Tuple, Union, List) but not comprehensive
- **Docstrings:** None found in any source files
- **Comments:** Minimal; only where logic is non-obvious (e.g., match-case handling)

### Issues
- No pre-commit hooks to auto-format
- No mypy config in pyproject.toml (though listed in dev dependencies)
- Import statements not consistently sorted (isort recommended)
- No type hints in TUI/GUI code (Qt types are complex, but could benefit)

## 13. Dependencies

### Core Dependencies
| Package | Version | Purpose |
|---------|---------|---------|
| sqlalchemy | >=2.0.0 | ORM and database abstraction |
| python-dotenv | >=1.2.2 | Load environment variables from .env |

### CLI Dependencies
| Package | Version | Purpose |
|---------|---------|---------|
| click | >=8.3.1 | Command-line interface framework |

### TUI Dependencies
| Package | Version | Purpose |
|---------|---------|---------|
| rich | >=14.3.3 | Rich text and beautiful formatting in terminal |

### GUI Dependencies
| Package | Version | Purpose |
|---------|---------|---------|
| pyside6 | >=6.10.2 | Qt6 bindings for Python |
| pyside6-fluent-widgets | >=1.11.1 | Fluent UI widget library |

### Dev Dependencies
| Package | Purpose |
|---------|---------|
| build | Build package for PyPI |
| pytest | Test framework |
| pytest-asyncio | Async test support (though no async code present) |
| black | Code formatter |
| isort | Import sorter |
| mypy | Static type checker |

### Dependency Management
- **No lockfile:** No `requirements.txt` or `poetry.lock`
- **Version specifiers:** Minimum versions only (>=x.y.z)
- **Risk:** Potential for breaking changes from upstream if minimum versions are updated without pinning
- **Recommendation:** Use `pip freeze > requirements.txt` for production deployments or adopt Poetry/uv

## 14. Security

### Authentication & Authorization
- **None required:** This is a single-user local application
- **No user accounts:** All data stored on user's machine
- **No network access:** No built-in sync, cloud backup, or telemetry

### Data Security
- **Local-only:** Database file is in user's home directory (`~/.momentum/main.db`)
- **File Permissions:** Created with default umask (typically 644/600 depending on OS)
- **No Encryption:** Database is plain SQLite file (readable by any user with file access)
- **SQL Injection:** Low risk - uses SQLAlchemy ORM with parameterized queries

### Consent & Privacy
- **User Agreement:** On first run, explicit Y/N consent required for file system access (stored in `config.json`)
- **No Telemetry:** No data collection, no external calls
- **No Analytics:** Completely offline

### Input Validation
- **CLI:** Parameters validated by Click (presence checks)
- **Logic Layer:**
  - Duplicate title check on save
  - ID existence checks on update/delete
  - Empty title/content checks
  - **Missing:** Sanitization of special characters, length limits, content filtering (XSS not applicable as not web-based)
- **GUI:** Client-side validation before calling Logic (title required, content required)

### Potential Concerns
1. **Broad Exception Catching:** Logic class catches `Exception` generically, rolls back, and prints message. Could hide specific errors.
2. **Path Traversal:** Not applicable - no user-supplied paths; only uses fixed `~/.momentum/` or env var.
3. **Dependency Security:** No pinned versions; could pull in vulnerable transitive dependencies if minimums are updated.
4. **No Integrity Checks:** Database has no checksums or integrity verification beyond SQLite's own WAL/journal (if enabled).
5. **Config File Tampering:** `config.json` is simple JSON; user could manually edit `agree` flag to bypass consent (but why would they?).

## 15. Unique Patterns & Conventions

### Architectural Patterns
1. **Truly Shared Core:** Unlike many multi-interface projects where core is just copied, this uses proper Python packaging with `momentum-core` as a dependency for all interfaces.
2. **Single Responsibility Logic:** `Logic` class is the only place business rules live. Interfaces are purely presentation.
3. **Color Theme Constant:** `core/utils/color_theme.py` provides a single source of truth for UI colors, used by both TUI (Rich) and GUI (Qt stylesheets). This ensures visual consistency across interfaces.
4. **Contextual Buttons:** GUI's submit button text changes between "Create" and "Update" based on `editing_id` state.
5. **Card Grid Layout:** GUI uses a responsive 4-column grid (`index // 4`, `index % 4`) for task cards.
6. **Not Repository Pattern:** The `Logic` class directly uses SQLAlchemy session objects rather than abstracting a repository layer. This is simple and appropriate for the scope.
7. **Generator-based Session Management:** `get_db()` yields a session and ensures closure in `finally`, allowing `next(get_db())` pattern in each method rather than DI or context managers.
8. **Environment-Aware DB URL:** Database configuration checks two env var names (`SQLALCHEMY_DB_URL` or `SQLALCHEMY_DATABASE_URL`) for flexibility.
9. **Mapping Not Dict:** Task model uses SQLAlchemy Column types, not a dictionary or dataclass.

### Code Conventions
- **Match-Case:** Uses Python 3.10+ structural pattern matching for user agreement handling (lines 55-65 in logic.py)
- **Module Exports:** Each `__init__.py` defines `__all__` to control public API
- **Package-Dir Setting:** Sub-packages use `package-dir = {"" = ".."}` in pyproject.toml to reference parent directory (monorepo trick)
- **Status Bar Feedback:** GUI uses colored status bar with auto-clear after 3 seconds (QTimer)
- **CLI Simplicity:** Minimal output, no colors, machine-parseable (space-separated sections)
- **TUI Polish:** Uses Rich's Panel with rounded boxes, styled text, centered alignment

### UI Patterns
1. **Multi-line Input:** TUI's content input allows '.' on new line to finish (similar to REPL)
2. **In-place Editing:** GUI's edit button populates form in place; no separate dialog
3. **Confirmation Before Delete:** TUI uses Rich's Confirm.ask; GUI has no confirmation dialog (uses immediate delete with undo not implemented)
4. **Auto-refresh:** After any write operation, both TUI and GUI reload task list

## 16. Issues, Inconsistencies, and Opportunities

### Critical Issues (Should Fix)

1. **No Automated Testing**
   - **Severity:** HIGH
   - **Impact:** No safety net for regressions, difficult to refactor
   - **Solution:** Implement unit tests for `Logic` class (mock DB), integration tests with in-memory SQLite

2. **Broad Exception Handling**
   - **Location:** `core/logic.py` lines 104, 134, 155
   - **Code:** `except Exception as e: print(...); db.rollback(); return failure`
   - **Issue:** Catches all exceptions including system exits, keyboard interrupts, database errors. Hides root cause from caller.
   - **Solution:** Catch specific SQLAlchemy errors (IntegrityError, NoResultFound, etc.), re-raise unexpected exceptions

3. **Missing Input Validation**
   - **CLI:** `commands.py` doesn't validate that `--title` and `--content` are provided before calling `logic.save_task()`. Relies on Logic validation.
   - **GUI:** Checks title and content non-empty but does not trim whitespace before validation; `strip()` called but empty string after strip still passes? (Actually checked: `if not new_title:` after strip is correct)
   - **Opportunity:** Add length limits (e.g., title max 100 chars), content size limits, character restrictions (no control chars)

4. **No Logging**
   - **Severity:** MEDIUM
   - **Issue:** Uses `print()` for errors and status messages. Not suitable for production debugging, no log levels, no file output.
   - **Solution:** Replace with `logging` module; configure different handlers for CLI (stdout) vs background; include timestamps, log levels.

5. **Hard-Coded Paths**
   - `~/.momentum/` is hard-coded in `Logic.__init__` and CLI/TUI/GUI main files.
   - **Opportunity:** Allow environment variable override (e.g., `MOMENTUM_HOME`) or config option.

### Medium Issues (Should Consider)

6. **Incomplete Package Structure**
   - `cli/__init__.py` and `tui/__init__.py` are missing (though Python 3.3+ allows namespace packages without __init__, having __init__ is conventional and may affect tooling).
   - **Solution:** Add empty `__init__.py` files (or export main functions).

7. **Inconsistent Type Hints**
   - `Logic.get_all_tasks()` returns `Union[List, None]` but actually returns `List[Task]` or empty list (never None if DB query returns empty list). Should be `List[Task]`.
   - GUI uses Qt types without imports (relies on PySide6.QtWidgets import *)
   - **Solution:** Audit and fix type hints; add stubs for Qt if using mypy.

8. **Database Schema Limitations**
   - Only `title` and `content` fields. No way to mark tasks complete, set priority, due dates, tags, etc.
   - **Opportunity:** Expand schema with `created_at`, `updated_at`, `completed_at`, `priority` (enum), `status` (todo/doing/done).
   - **Breaking Change:** Would require migration strategy (Alembic).

9. **No Configuration Options**
   - Only stores user agreement. No customization (theme colors, font sizes, layout preferences).
   - **Opportunity:** Add `config.json` schema with UI settings, last used interface, etc.

10. **GUI Usability Issues**
    - Delete has no confirmation dialog (immediate delete). Could lead to accidental data loss.
    - Task cards fixed size 250x300; long content clipped (no elide or tooltip).
    - No search/filter functionality.
    - No pagination if many tasks (scroll area might get slow with hundreds).
    - Edit mode doesn't preserve scroll position.

11. **CLI UX**
    - `list` command prints raw separators; could be tabular or JSON output option.
    - No `--json` flag for machine-readable output.
    - No pagination for long lists.

12. **TUX Usability**
    - Multi-line content input with '.' terminator is unusual; could use Ctrl+D or dedicated "Done" prompt.
    - No way to cancel during add/edit (Ctrl+C kills entire app).
    - Tables could overflow terminal width; no word wrap.

13. **Error Messages Vague**
    - "Unknown Exception" prints exception string to console but user sees generic "Failed to X" message.
    - Could expose internal errors to users unnecessarily.
    - **Solution:** Log full exception; show user-friendly message only.

14. **Dependency on python-dotenv**
    - `db.py` calls `load_dotenv()` but doesn't actually use `.env` file in default setup. It's unnecessary if only using env vars.
    - Could be removed if not used; or document `.env` support.

15. **Missing __init__.py in cli/tui**
    - While namespace packages work, having `__init__.py` ensures consistent behavior across tools (mypy, IDEs, setuptools).
    - Easy fix: create empty files.

### Low Issues / Opportunities

16. **No DB Migration Plan**
    - Simple `create_all()` will not alter existing tables if schema changes.
    - Future schema changes require manual migration or drop-and-recreate (data loss).
    - **Solution:** Integrate Alembic for migrations when schema stabilizes.

17. **No Data Validation Layer**
    - Validation logic is embedded in `Logic` methods (e.g., duplicate title check).
    - Could be extracted to separate validators or Pydantic models for clearer contract.

18. **No Background Operations**
    - All operations are synchronous; GUI freezes during DB operations (though fast for local SQLite).
    - Could use QThread or asyncio for responsiveness with large datasets.

19. **Icon Path in GUI**
    - `gui/main.py` uses `"./core/assets/icon.png"` relative path. When installed as package, resources should be accessed via `importlib.resources`.
    - Currently works only when running from repo root; installed package might fail.

20. **Thread Safety**
    - `get_db()` generator yields sessions without thread-local storage. If interfaces become multi-threaded (GUI with QThread), sessions could be shared inadvertently.
    - For now, single-threaded apps, so okay.

21. **Documentation Gaps**
    - No module-level or class docstrings
    - No README in `core/`, `cli/`, `tui/`, `gui/` subdirectories (though inherited from root maybe)
    - No API documentation for `Logic` class
    - Contributing guide lacks details on running specific parts, debugging, architecture diagram (though present in README)

22. **Code Duplication**
    - Error handling pattern (try/except/rollback) repeated in 3 methods; could be decorator or helper.
    - `get_user_agreement` echoes to stdout; should be abstracted for GUI/TUI if they want custom consent dialog (currently only CLI uses it but shared).

23. **Constants in Logic**
    - Config filename strings, app name, etc. are hard-coded. Could be module-level constants.
    - Duplicate `app_dir` creation in CLI/TUI/GUI vs Logic ( Logic also creates it).

24. **Packaging Inconsistencies**
    - Root pyproject.toml lists packages: `["cli", "core", "tui", "gui"]` but each subpackage also has its own pyproject.toml with `package-dir = {"": ".."}`.
    - This "parent-relative" packaging is unusual; typically monorepos use `find_packages(where=".")` or editable installs with `-e .`. Current setup works but could be simplified.
    - Version numbers in subprojects differ: core 1.0.0, gui 0.1.0, cli/tui 1.0.0. Should be synchronized.

25. **No Default Values for Optional Fields**
    - `logic.update_task()` requires both `new_title` and `new_content` parameters but defaults to `None`. When `None`, it doesn't update that field (good). But CLI command `edit` passes `None` for omitted options (correct).
    - GUI passes `title_input.text().strip()` which could be empty string if user cleared; then fails validation (good).
    - However, TUI edit passes `new_title` from Prompt.ask with default=task.title, so always non-empty; but if user presses Enter without typing, it keeps current (correct). Content handling: empty list yields `None` (via `if content_lines else None`), which means no update. This is correct but could be clearer.

26. **Database Engine Configuration**
    - `echo=False` means no SQL logging. Good for production but hard to debug. Could be enabled via debug flag.
    - `connect_args={"check_same_thread": False}` is necessary for SQLite but could cause issues if used with threads. Should document.

27. **Config File Corruption Handling**
    - `setup_environment()` catches `KeyError` and `JSONDecodeError` and deletes the config file, then re-prompts. This is good but could be more user-friendly (backup old file, show error).

28. **Future Updater Code**
    - CHANGELOG mentions updater application that was added then removed. Git history may still have code. Consider cleaning history or re-adding if needed.

### Security Improvements

29. **Rate Limiting / Abuse**
   - Not applicable for local app, but CLI could be scripted to flood DB. No rate limits. Could add max tasks limit or DB size quota.

30. **Secret Management**
   - Not relevant, but if future features include cloud sync, secrets should be stored in OS keyring, not config file.

### Performance Opportunities

31. **Batch Operations**
   - `get_all_tasks()` loads all tasks into memory. For thousands of tasks, could be slow. Could add pagination or lazy loading in GUI/TUI.

32. **UI Responsiveness**
   - GUI queries DB on every operation; fine for local but could debounce or cache.

### Maintainability

33. **Stale Dependencies**
   - Minimum versions from 2024-2026. Need to periodically update and test.
   - Use Dependabot or similar.

34. **No Pre-commit Hooks**
   - Project should adopt pre-commit with black, isort, flake8, mypy to ensure quality before commits.

35. **No Changelog Automation**
   - Manual CHANGELOG; could use git-chglog or conventional commits to auto-generate.

## Summary

**Momentum** is a well-architected, minimalist task management application that successfully implements a **shared-core monorepo** pattern with three polished user interfaces. The codebase is **small (547 lines)**, **readable**, and **consistent** in its design philosophy of local-first, no-nonsense task tracking.

**Strengths:**
- Clean separation of concerns (Core vs Interfaces)
- Consistent theming across TUI and GUI
- Proper use of modern Python (3.12+, match-case, pathlib)
- Good use of ORM (SQLAlchemy 2.0) with proper session management
- Comprehensive documentation (README, CONTRIBUTING, CHANGELOG)
- Active development (recent commits)

**Weaknesses:**
- **Zero test coverage** despite declared dev dependencies
- Broad exception handling masks errors
- No logging infrastructure
- Limited data model (basic fields only)
- Some UX rough edges (delete confirmation, GUI validation feedback)
- Minor packaging inconsistencies (missing `__init__`, version drift)

**Overall Assessment:** This is a **solid foundation** for a personal productivity tool. With moderate investment in testing, logging, and input validation, it could become a robust, production-ready application. The architecture is sound and extensible. The main risk is lack of tests, which makes future refactoring risky. Recommend prioritizing test coverage before adding new features.

**Code Quality Score:** 7/10 (Good, with room for improvement in testing and error handling)

---

**Report Generated:** 2026-03-07
**Codebase Analyzed:** /media/kastien/AI/DISCORD/mekasu/momentum (Git commit: 2a936a9)
